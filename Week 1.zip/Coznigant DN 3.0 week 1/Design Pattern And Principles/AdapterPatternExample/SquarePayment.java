public class SquarePayment {
    public void doPayment(double amount) {
        System.out.println("Processing Square payment of $" + amount);
    }
}
